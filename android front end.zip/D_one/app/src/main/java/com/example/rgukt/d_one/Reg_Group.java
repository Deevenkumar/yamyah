package com.example.rgukt.d_one;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by RGUKT on 16-Dec-17.
 */

public class Reg_Group extends AppCompatActivity {
    EditText g_name,g_size;
    TextView g_status,g_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_group);

        g_name = (EditText)findViewById(R.id.group_name);
        g_size = (EditText) findViewById(R.id.group_size);
        g_status = (TextView)findViewById(R.id.group_status);
        g_id = (TextView)findViewById(R.id.group_id);
    }

    public void groupReg(View v)
    {
        String group_name = g_name.getText().toString();
        String group_size = g_size.getText().toString();
        Random rand = new Random();
        String group_id = group_name + rand.nextInt(1000);

        Toast.makeText(this,"Saving Details....",Toast.LENGTH_LONG).show();

        SaveGroupDetails(group_id,group_name,group_size);
        g_status.setText("Success fully registed ");
        g_id.setText("Your Group id ::".concat(group_id));
    }
    public void SaveGroupDetails(String gid,String name,String size)
    {

        Toast.makeText(this,"Saving success ",Toast.LENGTH_LONG).show();
    }

}
