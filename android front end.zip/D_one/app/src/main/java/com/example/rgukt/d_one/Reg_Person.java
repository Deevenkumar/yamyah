package com.example.rgukt.d_one;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by RGUKT on 16-Dec-17.
 */

public class Reg_Person extends AppCompatActivity {
    EditText p_name,p_age,p_gender;
    TextView per_status;
    Button plus;
    LinearLayout ll;
    List<EditText> group_ids = new ArrayList<EditText>();
    int group_size = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_person);

        p_name= (EditText)findViewById(R.id.p_name);
        p_age = (EditText) findViewById(R.id.p_age);
        p_gender = (EditText)findViewById(R.id.p_gender);
        per_status = (TextView) findViewById(R.id.per_status);

        plus = (Button) findViewById(R.id.plus);
        ll = (LinearLayout) findViewById(R.id.group_fields);
        plus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EditText editText = new EditText(getBaseContext());
                editText.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                editText.setHint("Group id ");
                group_ids.add(editText);
                group_size++;
                ll.addView(editText);
            }
        });
    }


    public void personReg(View v)
    {
        String name = p_name.getText().toString();
        String age = p_age.getText().toString();
        String gender = p_gender.getText().toString();


        Toast.makeText(getApplicationContext(),name,Toast.LENGTH_SHORT).show();
        Toast.makeText(getApplicationContext(),age,Toast.LENGTH_SHORT).show();
        Toast.makeText(getApplicationContext(),gender,Toast.LENGTH_SHORT).show();
        int n = ll.getChildCount();
        StringBuilder groups = new StringBuilder("");
        for(int i=0;i<n;i++)
        {
            String k = ((EditText)ll.getChildAt(i)).getText().toString();
            groups.append(k);
            groups.append(',');
        }
        Toast.makeText(getApplicationContext(),groups.toString(),Toast.LENGTH_SHORT).show();


        // **************** Save here all the fields name,age,groups.toString().

        per_status.setText("Register Successfully");
    }


}
